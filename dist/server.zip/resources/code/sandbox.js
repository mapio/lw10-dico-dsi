// Usa questa applicazione per sperimentare liberamente!

DEBUG = true;

function init() {}
