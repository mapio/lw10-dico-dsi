DEBUG = true;

// Usa questa applicazione per sperimentare liberamente!